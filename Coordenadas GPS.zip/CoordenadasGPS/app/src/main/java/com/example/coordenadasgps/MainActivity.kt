package com.example.coordenadasgps

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity(), LocationListener {

    private lateinit var locationManager : LocationManager
    private lateinit var latitud : TextView
    private lateinit var longitud : TextView
    private lateinit var ultimaUbicacion: Location

    private val locationPermissionCode = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "KotlinApp"
        val button : Button = findViewById(R.id.getLocation)
        button.setOnClickListener{
            getLocation()
        }

        val button2 : Button = findViewById(R.id.getMapas)
        button2.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)

            if (::ultimaUbicacion.isInitialized) {
                val intent = Intent(this, MapsActivity::class.java)
                intent.putExtra("latitud", ultimaUbicacion.latitude)
                intent.putExtra("longitud", ultimaUbicacion.longitude)
                startActivity(intent)
            }
        }
    }

    private fun getLocation() {
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        if ((ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!=
                PackageManager.PERMISSION_GRANTED)) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), locationPermissionCode)
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5f, this)
    }

    override fun onLocationChanged(location: Location) {
        latitud = findViewById(R.id.latitud)
        longitud = findViewById(R.id.longitud)
        latitud.text = location.latitude.toString()
        longitud.text = location.longitude.toString()

        ultimaUbicacion = location
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == locationPermissionCode){
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
            } else{
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}